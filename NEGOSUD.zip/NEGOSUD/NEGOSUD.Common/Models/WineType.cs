﻿using System;
using NEGOSUD.Common.Core;

namespace NEGOSUD.Common.Models
{
	public class WineType : Entity 
	{
		public string Color { get; set; } = string.Empty;

	}
}

