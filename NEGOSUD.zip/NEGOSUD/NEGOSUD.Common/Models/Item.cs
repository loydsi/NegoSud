﻿using System;
using System.ComponentModel.DataAnnotations.Schema;
using NEGOSUD.Common.Core;

namespace NEGOSUD.Common.Models
{
	public class Item : Entity
	{
		public string Name { get; set; } = string.Empty;

        public string Appellation { get; set; } = string.Empty;

        public float Volume { get; set; } = float.MinValue;

        public int Year { get; set; } = int.MinValue;

        public float UnitPrice { get; set; } = float.MinValue;

        public float BoxPrice { get; set; } = float.MinValue;

        public string Region { get; set; } = string.Empty;

        public string Family { get; set; } = string.Empty;

        public string DomainName { get; set; } = string.Empty;

        public string Image { get; set; } = string.Empty;

        [ForeignKey("WineTypeId")]
        public int WineTypeId { get; set; }

        [ForeignKey("ProviderId")]
        public int ProviderId { get; set; }

    }
}

