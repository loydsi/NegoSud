﻿using System;
using System.ComponentModel.DataAnnotations.Schema;
using NEGOSUD.Common.Core;

namespace NEGOSUD.Common.Models
{
    public class OrderP : Entity
    {
        public string OrderNumber { get; set; } = string.Empty;

        public DateTime OrderDate { get; set; } = DateTime.MinValue;

        public int Quantity { get; set; } = int.MinValue;

        public float Price { get; set; } = float.MinValue;

        [ForeignKey("ProviderId")]
        public int ProviderId { get; set; }
        public virtual Provider Provider { get; set; }

        [ForeignKey("StatusId")]
        public int StatusId { get; set; }
        public virtual Status Status { get; set; }


        public OrderP()
        {
        
        }
    }
}

