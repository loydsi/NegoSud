﻿using System;
using System.ComponentModel.DataAnnotations.Schema;
using NEGOSUD.Common.Core;

namespace NEGOSUD.Common.Models
{
	public class OrderC : Entity
	{
		public string OrderNumber { get; set; } = string.Empty;

		public DateTime OrderDate { get; set; } = DateTime.MinValue;

		public DateTime DeliveryDate { get; set; } = DateTime.MinValue;

		public int Quantity { get; set; } = int.MinValue;

		public float Price { get; set; } = float.MinValue;

        [ForeignKey("CustomerId")]
        public int CustomerId { get; set; }
        public virtual Customer Customer { get; set; }

        [ForeignKey("StatusId")]
        public int StatusId { get; set; }
        public virtual Status Status { get; set; }

        public OrderC()
		{
        }
	}
}

