﻿using System;
using System.Data;
using System.Net.NetworkInformation;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using NEGOSUD.Common.Models;

namespace NEGOSUD.DataAccess.EntityConfiguration
{
	public class StatusEntityConfiguration : IEntityTypeConfiguration<Status>
    {
		public StatusEntityConfiguration()
		{
		}

        public void Configure(EntityTypeBuilder<Status> status)
        {
            status.HasKey(s => s.Id);
            status.Property(s => s.Id).ValueGeneratedOnAdd();

            status.Property<string>("Name").IsRequired();

            status.HasIndex(s => s.Name).IsUnique();

        }
    }
}

