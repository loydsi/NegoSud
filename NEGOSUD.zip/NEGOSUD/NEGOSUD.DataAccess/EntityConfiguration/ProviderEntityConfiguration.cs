﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using NEGOSUD.Common.Models;

namespace NEGOSUD.DataAccess.EntityConfiguration
{
	public class ProviderEntityConfiguration : IEntityTypeConfiguration<Provider>
    {
		public ProviderEntityConfiguration()
		{
		}

        public void Configure(EntityTypeBuilder<Provider> provider)
        {
            provider.ToTable("providers");
            provider.HasKey(p => p.Id);
            provider.Property(p => p.Id).ValueGeneratedOnAdd();

            provider.Property<string>("DomainName").IsRequired();
            provider.Property<string>("Phone").IsRequired();
            provider.Property<string>("Email").IsRequired();

            provider.HasIndex(p => p.Email).IsUnique();
        }
    }
}

