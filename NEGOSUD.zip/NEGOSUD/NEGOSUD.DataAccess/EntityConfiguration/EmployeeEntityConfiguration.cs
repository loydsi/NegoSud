﻿using System;
using System.Reflection.Emit;
using Microsoft.EntityFrameworkCore;
using NEGOSUD.Common.Models;

namespace NEGOSUD.DataAccess.EntityConfiguration
{
	public class EmployeeEntityConfiguration : IEntityTypeConfiguration<Employee>
	{
		public EmployeeEntityConfiguration()
		{
		}

        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<Employee> employee)
        {
            employee.HasKey(e => e.Id);
            employee.Property(e => e.Id).ValueGeneratedOnAdd();

            employee.Property<string>("Name").IsRequired();
            employee.Property<string>("LastName").IsRequired();
            employee.Property<string>("Email").IsRequired();
            employee.Property<string>("Password").IsRequired();

            employee.HasIndex(e => e.Email).IsUnique();
        }
    }
}

