﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using NEGOSUD.Common.Models;

namespace NEGOSUD.DataAccess.EntityConfiguration
{
	public class OrderCEntityConfiguration : IEntityTypeConfiguration<OrderC>
    {
		public OrderCEntityConfiguration()
		{
		}

        public void Configure(EntityTypeBuilder<OrderC> orderc)
        {
            orderc.HasKey(oc => oc.Id);
            orderc.Property(oc => oc.Id).ValueGeneratedOnAdd();

            orderc.Property<string>("OrderNumber").IsRequired();
            orderc.Property<DateTime>("OrderDate").IsRequired();
            orderc.Property<DateTime>("DeliveryDate").IsRequired();
            orderc.Property<int>("Quantity").IsRequired();
            orderc.Property<float>("Price").IsRequired();

            orderc.HasIndex(oc => oc.OrderNumber).IsUnique();
        }
    }
}

