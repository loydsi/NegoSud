﻿using System;
using NEGOSUD.Common.Models;

namespace NEGOSUD.Services.WineTypeService
{
	public interface IWineTypeService
	{
        Task<List<WineType>> GetAllWineTypes();

        Task<WineType?> GetOneWineType(int id);

        Task<List<WineType>> AddWineType(WineType wineType);

        Task<List<WineType>?> UpdateWineType(int id, WineType request);

        Task<List<WineType>?> DeleteWineType(int id);
    }
}

