﻿using System;
using Microsoft.EntityFrameworkCore;
using NEGOSUD.Common.Models;
using NEGOSUD.DataAccess;

namespace NEGOSUD.Services.OrderCService
{
	public class OrderCService : IOrderCService
	{
        private readonly DataContext _context;

        public OrderCService(DataContext context)
		{
            _context = context;
        }

        public async Task<List<OrderC>> AddOrderC(OrderC orderC)
        {
            _context.OrdersC.Add(orderC);
            await _context.SaveChangesAsync();

            return await _context.OrdersC.ToListAsync();
        }

        public async Task<List<OrderC>?> DeleteOrderC(int id)
        {
            var orderC = await _context.OrdersC.FindAsync(id);
            if (orderC is null)
                return null;

            _context.OrdersC.Remove(orderC);
            await _context.SaveChangesAsync();

            return await _context.OrdersC.ToListAsync();
        }

        public async Task<List<OrderC>> GetAllOrdersC()
        {
            var ordersC = await _context.OrdersC.ToListAsync();
            return ordersC;
        }

        public async Task<OrderC?> GetOneOrderC(int id)
        {
            var orderC = await _context.OrdersC.FindAsync(id);
            if (orderC is null)
                return null;

            return orderC;
        }

        public async Task<List<OrderC>?> UpdateOrderC(OrderC request)
        {
            var orderC = await _context.OrdersC.FindAsync(request.Id);
            if (orderC is null)
                return null;

            if (request.OrderNumber != string.Empty)
                orderC.OrderNumber = request.OrderNumber;

            if (request.OrderDate != DateTime.MinValue)
                orderC.OrderDate = request.OrderDate;

            if (request.DeliveryDate != DateTime.MinValue)
                orderC.DeliveryDate = request.DeliveryDate;

            if (request.Quantity != int.MinValue)
                orderC.Quantity = request.Quantity;

            if(request.Price != int.MinValue)
                orderC.Price = request.Price;

            await _context.SaveChangesAsync();

            return await _context.OrdersC.ToListAsync();
        }
    }
}

