﻿using System;
using NEGOSUD.Common.Models;

namespace NEGOSUD.Services.OrderCService
{
	public interface IOrderCService
	{
        Task<List<OrderC>> GetAllOrdersC();

        Task<OrderC?> GetOneOrderC(int id);

        Task<List<OrderC>> AddOrderC(OrderC orderC);

        Task<List<OrderC>?> UpdateOrderC(OrderC request);

        Task<List<OrderC>?> DeleteOrderC(int id);
    }
}

