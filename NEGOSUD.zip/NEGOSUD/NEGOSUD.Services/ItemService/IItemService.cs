﻿using System;
using NEGOSUD.Common.Models;

namespace NEGOSUD.Services.ItemService
{
	public interface IItemService
	{
        Task<List<Item>> GetAllItems();

        Task<Item?> GetOneItem(int id);

        Task<List<Item>> AddItem(Item item);

        Task<List<Item>?> UpdateItem(int id, Item request);

        Task<List<Item>?> DeleteItem(int id);
    }
}

