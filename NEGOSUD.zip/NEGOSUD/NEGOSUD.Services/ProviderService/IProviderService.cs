﻿using System;
using NEGOSUD.Common.Models;

namespace NEGOSUD.Services.ProviderService
{
	public interface IProviderService
	{
        Task<List<Provider>> GetAllProviders();

        Task<Provider?> GetOneProvider(int id);

        Task<List<Provider>> AddProvider(Provider provider);

        Task<List<Provider>?> UpdateProvider(int id, Provider request);

        Task<List<Provider>?> DeleteProvider(int id);
    }
}

