﻿using System;
using Microsoft.EntityFrameworkCore;
using NEGOSUD.Common.Models;
using NEGOSUD.DataAccess;

namespace NEGOSUD.Services.ProviderService
{
	public class ProviderService : IProviderService
	{
        private readonly DataContext _context;


        public ProviderService(DataContext context)
		{
            _context = context;
        }

        public async Task<List<Provider>> AddProvider(Provider provider)
        {
            _context.Providers.Add(provider);
            await _context.SaveChangesAsync();

            return await _context.Providers.ToListAsync();
        }

        public async Task<List<Provider>?> DeleteProvider(int id)
        {
            var provider = await _context.Providers.FindAsync(id);
            if (provider is null)
                return null;

            _context.Providers.Remove(provider);
            await _context.SaveChangesAsync();

            return await _context.Providers.ToListAsync();
        }

        public async Task<List<Provider>> GetAllProviders()
        {
            var providers = await _context.Providers.ToListAsync();
            return providers;
        }

        public async Task<Provider?> GetOneProvider(int id)
        {
            var provider = await _context.Providers.FindAsync(id);
            if (provider is null)
                return null;

            return provider;
        }

        public async Task<List<Provider>?> UpdateProvider(int id, Provider request)
        {
            var provider = await _context.Providers.FindAsync(request.Id);
            if (provider is null)
                return null;
            
            if (request.DomainName != string.Empty)
                provider.DomainName = request.DomainName;
            if (request.Phone != string.Empty)
                provider.Phone = request.Phone;

            if (request.Email != string.Empty)
                provider.Email = request.Email;

            if (request.Phone != string.Empty)
                provider.Phone = request.Phone;

            if (request.PostalCode != string.Empty)
                provider.PostalCode = request.PostalCode;

            if (request.City != string.Empty)
                provider.City = request.City;

            if (request.Street != string.Empty)
                provider.Street = request.Street;

            await _context.SaveChangesAsync();

            return await _context.Providers.ToListAsync();
        }
    }
}

