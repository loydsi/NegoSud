﻿using NEGOSUD.DataAccess;
using NEGOSUD.Services.ItemService;
using NEGOSUD.Services.ProviderService;
using NEGOSUD.Services.EmployeeService;
using NEGOSUD.Services.WineTypeService;
using NEGOSUD.Services.CustomerService;
using NEGOSUD.Services.OrderPService;
using NEGOSUD.Services.RoleService;
using NEGOSUD.Services.StatusService;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddScoped<ICustomerService, CustomerService>();
builder.Services.AddScoped<IEmployeeService, EmployeeService>();
builder.Services.AddScoped<IItemService, ItemService>();
builder.Services.AddScoped<IOrderPService, OrderPService>();
builder.Services.AddScoped<IProviderService, ProviderService>();
builder.Services.AddScoped<IRoleService, RoleService>();
//builder.Services.AddScoped<IStatusService, StatusService>();
builder.Services.AddScoped<IWineTypeService, WineTypeService>();
builder.Services.AddDbContext<DataContext>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.UseCors(builder => builder
     .AllowAnyOrigin()
     .AllowAnyMethod()
     .AllowAnyHeader());

app.Run();

