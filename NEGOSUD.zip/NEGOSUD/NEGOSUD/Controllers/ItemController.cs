﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using NEGOSUD.Common.Models;
using NEGOSUD.Services.ItemService;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace NEGOSUD.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ItemController : ControllerBase
    {
        private readonly IItemService _itemService;

        public ItemController(IItemService itemService)
        {
            _itemService = itemService;

        }

        // GET: api/values
        [HttpGet]
        public async Task<ActionResult<List<Item>>> GetAllItems()
        {
            return await _itemService.GetAllItems();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Item>> GetOneItem(int id)
        {
            var result = await _itemService.GetOneItem(id);
            if (result is null)
                return NotFound("Item not found.");

            return Ok(result);
        }

        [HttpPost]
        public async Task<ActionResult<List<Item>>> AddItem(Item item)
        {
            var result = await _itemService.AddItem(item);
            return Ok(result);
        }

        [HttpPut("{id}")]
        public async Task<ActionResult<List<Item>>> UpdateItem(int id, Item request)
        {
            var result = await _itemService.UpdateItem(id, request);
            if (result is null)
                return NotFound("Item not found.");

            return Ok(result);
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult<List<Item>>> DeleteItem(int id)
        {
            var result = await _itemService.DeleteItem(id);
            if (result is null)
                return NotFound("Item not found.");

            return Ok(result);
        }
    }
}

