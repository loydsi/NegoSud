﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using NEGOSUD.Common.Models;
using NEGOSUD.Services.StatusService;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace NEGOSUD.Controllers
{
    [Route("api/[controller]")]
    public class StatusController : ControllerBase
    {
        private readonly IStatusService _statusService;

        public StatusController(IStatusService statusService)
        {
            _statusService = statusService;
        }

        // GET: api/values
        [HttpGet]
        public async Task<ActionResult<List<Status>>> GetAllStatus()
        {
            return await _statusService.GetAllStatus();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Status>> GetOneStatus(int id)
        {
            var result = await _statusService.GetOneStatus(id);
            if (result is null)
                return NotFound("Status not found.");

            return Ok(result);
        }

        [HttpPost]
        public async Task<ActionResult<List<Status>>> AddStatus(Status status)
        {
            var result = await _statusService.AddStatus(status);
            return Ok(result);
        }

        [HttpPut]
        public async Task<ActionResult<List<Status>>> UpdateStatus(Status request)
        {
            var result = await _statusService.UpdateStatus(request);
            if (result is null)
                return NotFound("Status not found.");

            return Ok(result);
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult<List<Status>>> DeleteStatus(int id)
        {
            var result = await _statusService.DeleteStatus(id);
            if (result is null)
                return NotFound("Status not found.");

            return Ok(result);
        }
    }
}

