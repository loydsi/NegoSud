﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using NEGOSUD.Common.Models;
using NEGOSUD.Services.WineTypeService;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace NEGOSUD.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class WineTypeController : ControllerBase
    {
        private readonly IWineTypeService _wineTypeService;

        public WineTypeController(IWineTypeService wineTypeService)
        {
            _wineTypeService = wineTypeService;
        }

        // GET: api/values
        [HttpGet]
        public async Task<ActionResult<List<WineType>>> GetAllWineTypes()
        {
            return await _wineTypeService.GetAllWineTypes();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<WineType>> GetOneWineType(int id)
        {
            var result = await _wineTypeService.GetOneWineType(id);
            if (result is null)
                return NotFound("WineType not found.");

            return Ok(result);
        }

        [HttpPost]
        public async Task<ActionResult<List<WineType>>> AddWineType(WineType wineType)
        {
            var result = await _wineTypeService.AddWineType(wineType);
            return Ok(result);
        }

        [HttpPut("{id}")]
        public async Task<ActionResult<List<WineType>>> UpdateWineType(int id, WineType request)
        {
            var result = await _wineTypeService.UpdateWineType(id, request);
            if (result is null)
                return NotFound("WineType not found.");

            return Ok(result);
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult<List<WineType>>> DeleteWineType(int id)
        {
            var result = await _wineTypeService.DeleteWineType(id);
            if (result is null)
                return NotFound("WineType not found.");

            return Ok(result);
        }
    }
}

