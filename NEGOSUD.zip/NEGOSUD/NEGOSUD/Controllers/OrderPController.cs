﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using NEGOSUD.Common.Models;
using NEGOSUD.Services.OrderPService;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace NEGOSUD.Controllers
{
    [Route("api/[controller]")]
    public class OrderPController : ControllerBase
    {
        private readonly IOrderPService _orderPService;

        public OrderPController(IOrderPService orderPService)
        {
            _orderPService = orderPService;

        }

        // GET: api/values
        [HttpGet]
        public async Task<ActionResult<List<OrderP>>> GetAllOrdersP()
        {
            return await _orderPService.GetAllOrdersP();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<OrderP>> GetOneOrderP(int id)
        {
            var result = await _orderPService.GetOneOrderP(id);
            if (result is null)
                return NotFound("OrderP not found.");

            return Ok(result);
        }

        [HttpPost]
        public async Task<ActionResult<List<OrderP>>> AddOrderP(OrderP orderP)
        {
            var result = await _orderPService.AddOrderP(orderP);
            return Ok(result);
        }

        [HttpPut]
        public async Task<ActionResult<List<OrderP>>> UpdateOrderP(OrderP request)
        {
            var result = await _orderPService.UpdateOrderP(request);
            if (result is null)
                return NotFound("OrderP not found.");

            return Ok(result);
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult<List<OrderP>>> DeleteOrderP(int id)
        {
            var result = await _orderPService.DeleteOrderP(id);
            if (result is null)
                return NotFound("OrderP not found.");

            return Ok(result);
        }
    }
}

